import mobiscroll from '../src/js/frameworks/javascript';

// Components
import '../src/js/forms.javascript';
import '../src/js/page.javascript';

import './mobiscroll.common';

export default mobiscroll;
